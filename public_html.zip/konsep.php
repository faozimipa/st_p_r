<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Statistika Parametrik</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>
<style>
.button { text-align:center; font-size:.90em;}
.button span { display:inline-block; background:url(images/button-side.gif) no-repeat left top; padding-left:1px;}
.button span span { background:url(images/button-side.gif) no-repeat right top; padding-right:1px; padding-left:0;}
.button span span a { display:inline-block; background:url(images/button-bg.gif) left top repeat-x; padding:0 0 3px 0; color:#d5c6bb; width:350px; height:40px;; text-decoration:none; text-transform:uppercase; font-weight:bold;}
.button span span a:hover { text-decoration:underline;}
</style>

<body>

<div id="wrapper">

	<div id="header">
	<h1>Parametrik Jitu</h1>
	<h2>Memecahkan Masalah Data Statistik Anda...</h2>	
	</div>
<div id="jalan2">
<marquee>Selamat datang di Web Parametrik Jitu, silahkan untuk menginput, memproses dan menganalisis data Anda, Terima Kasih</marquee>
</div>
	<div id="menu">
		<ul>
			<li><a href="index.php"><span>Home</span></a></li>
			<li><a href="konsep.php"><span>Konsep Dasar</span></a></li>
			<li><a href="data.php"><span>Data</span></a></li>
			<li><a href="hubungan.php"><span>Uji Hubungan</span></a></li>
			<li><a href="banding.php"><span>Uji Banding</span></a></li>
			<li><a href="taufiq.php">My Profile</a></li>
			<li><a href="bantuan.php">Bantuan</a></li>
		</ul>
		</ul>
	</div>

	
	
				<div class="entry">
				<br>
				<div class="button"><span><span><a href="konsep1.php">Korelasi 2 Variabel</a></span></span></div>
				<div class="button"><span><span><a href="konsep2.php">Regresi Sederhana</a></span></span></div>
				<div class="button"><span><span><a href="konsep3.php">Regresi Ganda 2 Variabel Independen</a></span></span></div>
				<div class="button"><span><span><a href="konsep4.php">Uji Banding Satu Sampel</a></span></span></div>
				<div class="button"><span><span><a href="konsep5.php">Uji Banding Sampel Berpasangan</a></span></span></div>
				<div class="button"><span><span><a href="konsep6.php">Uji Banding Dua Sampel Tidak Berpasangan</a></span></span></div>
				
			

	<div id="footer">
		
	</div>

</div>

</body>
</html>
