<html>
  <head>
    <title>Parametrik Online</title>
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <style>
      h1 {
        text-align: center;
      }
    </style>
  </head>
  <body>
    <h1>F tabel</h1>
    <center><img src="tabelf.png" width="100%" height="100%"></img><img src="tabelf1.png" width="100%" height="100%"></img></center>
  </body>
</html>