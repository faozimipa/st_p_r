<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
		<div class="entry">
				<br>
			<center><div class="entry-title"><h2>Regresi Ganda</h2></div>
		<p><hr></center>
			Analisis regresi linier berganda adalah hubungan secara linear antara dua atau lebih variabel independen (X1, X2,….Xn) dengan variabel dependen (Y). Analisis ini untuk mengetahui arah hubungan antara variabel independen dengan variabel dependen apakah masing-masing variabel independen berhubungan positif atau negatif dan untuk memprediksi nilai dari variabel dependen apabila nilai variabel independen mengalami kenaikan atau penurunan. Data yang digunakan biasanya berskala interval atau rasio. Persamaan Regresi Linear Ganda Model regresi linear ganda atas   akan ditaksir oleh
 <br><center><img src="3.png"></img></center>
<br>Dengan a0,a1,a2,...,ak  merupakan korfisien-koefisien yang harus ditentukan berdasarkan data hasil pengamatan. Analisis regresi linear berganda memerlukan pengujian secara serempak dengan menggunakan F hitung. Signifikansi ditentukan dengan membandingkan F hitung dengan F tabel atau melihat signifikansi pada output SPSS.
<br>Pengujian asumsi klasik regresi linier ganda:
<br> 1. Uji Normalitas
<br> 2. Uji Homogenitas
<br> 3. Uji Multikolinieritas
<br> 4. Uji Autokorelasi
<br> 5. Uji Heteroskedastisitas

</html>
