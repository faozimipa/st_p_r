<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

				<div class="entry">
				<br>
				<div class="entry-title"><h3>Regresi Sederhana</h3></div><hr>
			<form method="post" action="proses.php">
				<table>
			<tr><td>Masukkan Nama Tabel</td>
			<td><input type="text" name="nama" /></td></tr>  
			<tr><td colspan="2">*Jika tabel tidak ada, Masukkan data pada menu Data</td></tr>
			<tr><td>Masukkan Nama Variabel X</td> 
			<td><textarea name="x" id="x" cols="22" rows="1"></textarea></td></tr>
			<tr><td>Masukkan Nama Variabel Y</td> 
			<td><textarea name="y" id="y" cols="22" rows="1"></textarea></td></tr>
			</table>
		<input type="submit" name="submit" value="Submit" />
		</form>
		
			<br>
			<br>
		</div>
</html>
