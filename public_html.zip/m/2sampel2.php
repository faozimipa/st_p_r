<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

				<div class="entry">
				<br>
				<div class="entry-title"><h3>Input Data Dua Variabel Tak Berpasangan</h3></div><br>
			
		<form method="post" action="2data2.php"> 
		<table>
			<tr><td>
		Masukkan Nama Tabel</td>
			<td><textarea name="nama" id="nama" cols="22" rows="1"></textarea></td></tr> 
		<tr><td>Masukkan Banyaknya n Kelompok 1</td><td><input type="text" name="n1" /></td></tr>
		<tr><td>Masukkan Banyaknya n Kelompok 2</td><td><input type="text" name="n2" /></td></tr>
			</table><br><input type="submit" name="submit" value="Submit" /> </form>
			<br>
		NB : Nama tabel harus yang belum ada atau yang belum tersimpan di aplikasi ini, untuk melihat daftar nama tabel yang sudah ada klik pilihan "Lihat data" pada menu "Data"

			<br>
		</div>


