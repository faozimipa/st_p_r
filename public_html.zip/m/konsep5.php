<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
				<div class="entry">
				<br>
			<center><div class="entry-title"><h2>Uji T Sampel Berpasangan</h2></div>
		<p><hr></center>
Menurut Sukestiyarno, uji T berpasangan atau sering diistilakan dengan Paired Sampel t-Test, adalah jenis uji statistika yang bertujuan untuk membandingkan rata-rata dua grup yang saling berpasangan. Sampel berpasangan dapat diartikan sebagai sebuah sampel dengan subjek yang sama namun mengalami 2 perlakuan atau pengukuran yang berbeda, yaitu pengukuran sebelum dan sesudah dilakukan sebuah perlakuan.			
	<br>Rumus t-test yang digunakan untuk sampel berpasangan (paired) adalah:
<br><center><img src="konsep5.PNG"></img></center>
<img src="ketkonsep5.PNG"></img>
</html>
