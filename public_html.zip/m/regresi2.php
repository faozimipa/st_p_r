<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

				<div class="entry">
				<br>
				<div class="entry-title">Regresi Ganda 2 Variabel Independen</div><br>
			<div>Masukkan Data</div>
		<form method="post" action="proses7.php">
				<table>
			<tr><td>Masukkan Nama Tabel</td>
			<td><input type="text" name="nama" /></td></tr>  
			<tr><td colspan="2">*Jika tabel tidak ada, Masukkan data pada menu Data</td></tr>
			<tr><td>Masukkan Nama Variabel X1</td> 
			<td><textarea name="x1" id="x1" cols="22" rows="1"></textarea></td></tr>
			<tr><td>Masukkan Nama Variabel X2</td> 
			<td><textarea name="x2" id="x2" cols="22" rows="1"></textarea></td></tr>
			<tr><td>Masukkan Nama Variabel Y</td> 
			<td><textarea name="y" id="y" cols="22" rows="1"></textarea></td></tr>
			</table>
		<input type="submit" name="submit" value="Submit" />
		</form>
		
			<br>
			<br>
		</div>
</html>
