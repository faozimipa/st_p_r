<?php
$host = "localhost";
$username = "statistikastarco_stat";
$password = "J6*6&9N@iAT*";
$databasename = "statistikastarco_stat";
$connection = mysql_connect($host, $username, $password) or die("Kesalahan Koneksi ... !!");
mysql_select_db($databasename, $connection) or die("Databasenya Error");
?>