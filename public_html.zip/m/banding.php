<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<style>
.button { text-align:center; font-size:.90em;padding-top:2px;}
.button span { display:inline-block; background:blue; padding-left:1px;}
.button span span { background:blue; padding-right:1px; padding-left:0;}
.button span span a { display:inline-block; background:blue; padding:0 0 3px 0; color:#d5c6bb; width:300px; min-height:40px;; text-decoration:none; text-transform:uppercase; font-weight:bold;}
.button span span a:hover { text-decoration:underline;}
</style>				<div class="entry">
				<br>
			
			<div class="button"><span><span><a href="ujit1.php">Uji Banding Satu Sampel</a></span></span></div>
			<div class="button"><span><span><a href="paired.php">Uji Banding Sampel Berpasangan</a></span></span></div>
			<div class="button"><span><span><a href="independen.php">Uji Banding Dua Sampel Tidak Berpasangan</a></span></span></div>
			
			
		</div>
</html>
