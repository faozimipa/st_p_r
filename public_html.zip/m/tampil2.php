<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	
				<div class="entry">
				<br>
			<center><div class="entry-title">Data Dua Variabel</div><br>
       <table border="1"><tr><td>data X / kelompok sebelum</td><td>data Y / kelompok sesudah</td></tr>
	    <?php
    //file siswa.php
	include "db_connect.php";
    $kelas = $_GET['nama'];
    $query = mysql_query("select * from tabel2 where nama='".$kelas."'");
    while($siswa = mysql_fetch_array($query)){
    	echo '<tr><td>'.$siswa['x'].'</td><td>'.$siswa['y'].'</td></tr>';
    }?></table></center>
</html>
