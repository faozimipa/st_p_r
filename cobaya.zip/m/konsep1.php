<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
				<div class="entry">
				<br>
			<center><div class="entry-title"><h2>Korelasi</h2></div>
			<p><hr></center>
			Korelasi Sederhana merupakan suatu Teknik Statistik yang dipergunakan untuk mengukur kekuatan hubungan 2 Variabel dan juga untuk dapat mengetahui bentuk hubungan antara 2 Variabel tersebut dengan hasil yang sifatnya kuantitatif. Kekuatan hubungan antara 2 variabel yang dimaksud disini adalah apakah hubungan tersebut ERAT, LEMAH,  ataupun TIDAK ERAT sedangkan bentuk hubungannya adalah apakah bentuk korelasinya Linear Positif  ataupun Linear Negatif.
<br>Kekuatan Hubungan antara 2 Variabel biasanya disebut dengan Koefisien Korelasi dan dilambangkan dengan symbol "r". Nilai Koefisian r akan selalu berada di antara -1 sampai +1.
	<br>Rumus yang dipergunakan untuk menghitung Koefisien Korelasi Sederhana adalah sebagai berikut :
(Rumus ini disebut juga dengan Pearson Product Moment)
<br><center><img width="100%" src="r.png"></img></center>
</html>
