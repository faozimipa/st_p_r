<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
			<div class="entry">
				<br>
			<center><div class="entry-title"><h2>Regresi Sederhana</h2></div>
			<p><hr></center>
			Analisis regresi dipergunakan untuk melihat hubungan satu arah antara variabel yang lebih khusus, dimana variabel x berfungsi sebagai variabel bebas  variabel yang mempengaruhi, dan variabel y sebagai variabel terikat adalah variabel yang dipengaruhi. Biasanya variabel x juga disebut sebagai variabel independen atau variabel responden, dan variabel y sebagai variabel dependen
<br>Analisis regresi linear sederhana dipergunakan untuk mengetahui pengaruh antara satu buah variabel bebas terhadap satu buah variabel terikat. Analisis regresi linear sederhana dinyatakan dengan hubungan persamaan regresi:
<br><center><img src="2.png"></img></center>
<br>Pengujian asumsi klasik regresi linier ganda:
<br> 1. Uji Normalitas
<br> 2. Uji Homogenitas
</html>
