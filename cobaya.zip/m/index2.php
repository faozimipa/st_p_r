<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	
				<div class="entry">
				<br>
			<center><div class="entry-title">Aplikasi Statistika Inferensial Parametrik</div>
			<p>______________________________
			<br><br>Riza Arifudin, S.Pd., M. Cs<br>Putriaji Hendikawati, S.Si., M.Pd., M.Sc.</p>
			
<center><img width="30%" src="warna.jpg"></img></center>
			
		</div></center>

</div>

</body>
</html>
