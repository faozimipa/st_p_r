<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	
				<div class="entry">
				<br>
			
			<center><b>BIODATA DIRI</center></b>
<center>
<br>
<table border="0" cellpadding="0" cellspacing="2">
<tr>
<td width="11%">Nama</td>
<td width="3%">:</td>
<td width="86">Ahmad Noor Taufiq</td>
</tr>
<tr>
<td width="11%">TTL</td>
<td width="3%">:</td>
<td width="86">Kudus, 27 Oktober 1994</td>
</tr>
<tr>
<td width="11%">Alamat</td>
<td width="3%">:</td>
<td width="86">Nganguk Wali RT 02 RW 03 Kramat, Kudus</td>
</tr>
<tr>
<td width="11%">Pekerjaan</td>
<td width="3%">:</td>
<td width="86">D3 Staterkom</td>
</tr>
<tr>
<td width="11%">CP</td>
<td width="3%">:</td>
<td width="86">0857272836346</td>
</tr>
<tr>
<td width="11%">Email</td>
<td width="3%">:</td>
<td width="86">ahmadnoortaufiq@gmail.com</td>
</tr>
<tr>
<td width="11%">Motto</td>
<td width="3%">:</td>
<td width="86">Memang baik jadi orang penting, tapi lebih penting jadi orang baik</td>
</tr>
</table><br>
<a href="login.php"><span><b>Masuk sebagai admin</b></span></a>
		</center></div>
</html>
