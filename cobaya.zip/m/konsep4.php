<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
			<div class="entry">
				<br>
			<center><div class="entry-title"><h2>Uji T Satu Sampel</h2></div>
		<p><hr></center>
			Menurut Sudjana, statistik parametrik yang dapat digunakan untuk menguji hipotesis deskriptif bila datanya interval atau rasio adalah t-test 1 sampel. Terdapat dua macam pengujian hipotesis deskriptif yaitu dengan uji dua pihak (two tail test) dan uji satu pihak (one tail test). Uji satu pihak ada dua macam yaitu uji pihak kanan dan uji pihak kiri. Jenis uji mana yang akan digunakan tergantung pada bunyi kalimat hipotesis. Untuk menguji hipotesis deskriptif (satu sampel) yang datanya interval atau ratio menggunakan rumus berikut ini.
<br><center><img src="konsep4.png"></img></center>
<img src="ketkonsep4.png"></img>
</html>
