<?php
/**
 * Created by PhpStorm.
 * User: FAOZI
 * Date: 1/15/2017
 * Time: 7:37 AM
 * Email: faozimipa@gmail.com
 */

include("scripts.php");

?>

<script>
$(function () {
    $.material.init();
    $(".selectTable").select2();

  });
</script>