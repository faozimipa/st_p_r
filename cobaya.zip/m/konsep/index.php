<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('../common/header.php'); ?>
</head>
<body>
<div class="container">
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/korelasi.php">Korelasi 2 Variabel</a>
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/regresi.php">Regresi Sederhana</a>
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/regresi_ganda.php">Regresi Ganda 2 Variabel Independen</a>
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/uji_t.php">Uji Banding Satu Sampel</a>
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/uji_t_pasangan.php">Uji Banding Sampel Berpasangan</a>
    <a class="btn btn-block btn-raised btn-info" href="./m/konsep/uji_t_tak_pasangan.php">Uji Banding Dua Sampel Tidak Berpasangan</a>
</div>

<?php include ('../common/footer.php'); ?>
			