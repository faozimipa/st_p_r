<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<style>
a {
	text-decoration:none;
	color:#B4C835;
	}
a:hover {
	text-decoration:none;
	color:#6CC7DC;
	}
</style>	
	<div class="entry">
				<br>
				<center><div class="entry-title">Tabel Data Pengujian</div></center><br>
			<center><table border="1">
			<tr><td>Menu Pilihan</td><td><center>Untuk Pengujian</center></td></tr>
			<tr><td><center><a href="1sampel.php">Input data </a></center></td><td rowspan="3"><center>Uji Banding Satu Sampel</center></td></tr>
			<tr><td><center><a href="importdata1.php">Upload data </a></center></td></tr>
			<tr><td><center><a href="lihatdata1.php">Lihat data </a></center></td></tr>
			<tr><td><center><a href="2sampel.php">Input data </a></center></td><td rowspan="3"><center>Uji Korelasi, Uji Regresi Sederhana, Uji Banding 2 Sampel Berpasangan</center></td></tr>
			<tr><td><center><a href="importdata2.php">Upload data </a></center></td></tr>
			<tr><td><center><a href="lihatdata2.php">Lihat data </a></center></td></tr>
			<tr><td><center><a href="2sampel2.php">Input data </a></center></td><td rowspan="3"><center>Uji Banding 2 Sampel Tidak Berpasangan</center></td></tr>
			<tr><td><center><a href="2importdata2.php">Upload data </a></center></td></tr>
			<tr><td><center><a href="2lihatdata2.php">Lihat data </a></center></td></tr>
			<tr><td><center><a href="3sampel.php">Input data </a></center></td><td rowspan="3"><center>Uji Regresi Ganda 2 Variabel Independen</center></td></tr>
			<tr><td><center><a href="importdata3.php">Upload data </a></center></td></tr>
			<tr><td><center><a href="lihatdata3.php">Lihat data </a></center></td></tr>
			</table></center>
			
			<br>
		
			<br>
			<br>
		</div></html>
