<!DOCTYPE html>
<html lang="en">
<head>
	<?php include('common/header.php') ?>
</head>
<body style="background-color: white">
	<div class="entry">
				<br>
			<center>
					<div class="entry-title"><strong>Aplikasi Statistika Inferensial Parametrik</strong></div>
				<hr>
				<br><br>Riza Arifudin, S.Pd., M. Cs<br>Putriaji Hendikawati, S.Si., M.Pd., M.Sc.</p>
					<img width="200 px" src="warna.jpg"></img>
			</center>
	</div>

</body>
<?php include('common/footer.php') ?>
</html>
