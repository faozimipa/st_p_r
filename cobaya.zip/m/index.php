				<div class="entry">
				<br>
			<center><div class="entry-title"><strong>Aplikasi Statistika Inferensial Parametrik</strong></div>
			<p><hr>
			<br><br>Riza Arifudin, S.Pd., M. Cs<br>Putriaji Hendikawati, S.Si., M.Pd., M.Sc.</p>
<center><img width="60%" src="warna.jpg"></img></center>
		</div></center>
