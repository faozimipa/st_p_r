<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Statistika Parametrik</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>

<body>

<div id="wrapper">

	<div id="header">
		<h1>Parametrik Online</h1>
	</div>

	<div id="menu">
		<ul>
			<li><a href="index.php"><span>Home</span></a></li>
			<li><a href="regresi.php"><span>Regresi</span></a></li>
			<li><a href="korelasi.php"><span>Korelasi</span></a></li>
			<li><a href="ujit.php"><span>Uji T</span></a></li>
			<li><a href="anggota.php">Anggota</a></li>
		</ul>
		</ul>
	</div>

	
	
				<div class="entry"><br>
				<div class="entry-title">Regresi</div><br>
				<br>
			<div>Masukkan Data</div>
			<br>
		<form method="POST" action="proses2.php">
Nilai A<input name="nilaia" type="text" id="nilaia">
Nilai B<input name="nilaib" type="text" id="nilaib">
Nilai X<input name="nilaix" type="text" id="nilaix"><br><br>
<input type="submit" name="Submit" value="Hitung">
</form>
			<br>
			<br>
		</div>


	<div id="footer">
		
	</div>

</div>

</body>
</html>
