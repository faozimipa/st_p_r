<html>
  <head>
    <title>Parametrik Online</title>
    <script type="text/javascript" src="scripts/jquery.js"></script>
    <style>
      h1 {
        text-align: center;
      }
    </style>
  </head>
  <body>
    <h1>Tabel D / Tabel Kolmogorov Smirnov</h1>
    <center><img src="tabeld.png" width="500" height="100%"></img></center>
  </body>
</html>