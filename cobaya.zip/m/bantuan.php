<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

	
				<div class="entry">
				<br>
			<div class="entry-title"><center>Petunjuk Penggunaan Aplikasi</center></div>
			<br><br>
			<table border="1">
			
			<tr><td>1</td><td> Sebelum melakukan pengujian statistika di aplikasi ini masukkan data yang akan dianalisis dengan mengklik menu Data.</td></tr>
			<tr><td>2</td><td> Anda bisa masukkan data secara manual dengan mengklik pilihan Input data atau anda bisa mengambil data dari excel dengan format xls dengan mengklik Import data sesuai dengan berapa variabel/sampel dan uji statistik yang akan anda gunakan.</td></tr> 
			<tr><td>3</td><td> Apabila anda memasukkan data secara manual, masukkan nama tabel secara bebas yang belum belum ada atau yang belum tersimpan di aplikasi, kemudian masukkan jumlah data (n) sesuai dengan data anda.</td></tr>
			<tr><td>4</td><td> Apabila anda memasukkan data dengan cara upload, buat tabel data di excel dengan format tabel harus seperti pada contoh gambar di halaman Upload data dan nama tabel yang dibuat harus yang belum belum ada atau yang belum tersimpan di aplikasi, kemudian simpan dengan format xls, lalu klik tombol Browse untuk memilih file dan klik tombol Upload untuk mengupload data ke aplikasi.</td></tr>
			<tr><td>5</td><td> Kemudian analisis data yang telah anda masukkan menggunakan uji statistika di aplikasi ini sesuai keinginan anda dengan memasukkan nama tabel yang telah anda masukkan dan masukkan nama variabel data anda.</td></tr>
			<tr><td>6</td><td> Setelah itu perhitungan dan analisis dari data anda akan muncul.</td></tr>
			
			</td></tr></table>
		</div>
</html>
