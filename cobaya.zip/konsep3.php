<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Statistika Parametrik</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>

<body>

<div id="wrapper">

	<div id="header">
	<h1>Parametrik Online</h1>
	<h2>Memecahkan Masalah Data Statistik Anda...</h2>	
	</div>
<div id="jalan2">
<marquee>Selamat datang di Web Parametrik Online, silahkan untuk menginput, memproses dan menganalisis data Anda, Terima Kasih</marquee>
</div>
	<div id="menu">
		<ul>
			<li><a href="index.php"><span>Home</span></a></li>
			<li><a href="konsep.php"><span>Konsep Dasar</span></a></li>
			<li><a href="data.php"><span>Data</span></a></li>
			<li><a href="hubungan.php"><span>Uji Hubungan</span></a></li>
			<li><a href="banding.php"><span>Uji Banding</span></a></li>
			<li><a href="taufiq.php">My Profil</a></li>
			<li><a href="bantuan.php">Bantuan</a></li>
		</ul>
		</ul>
	</div>

	
	
				<div class="entry">
				<br>
			<center><div class="entry-title">Rgresi Ganda</div>
			<p>_________________________________________________________</center>
			Analisis regresi linier berganda adalah hubungan secara linear antara dua atau lebih variabel independen (X1, X2,….Xn) dengan variabel dependen (Y). Analisis ini untuk mengetahui arah hubungan antara variabel independen dengan variabel dependen apakah masing-masing variabel independen berhubungan positif atau negatif dan untuk memprediksi nilai dari variabel dependen apabila nilai variabel independen mengalami kenaikan atau penurunan. Data yang digunakan biasanya berskala interval atau rasio. Persamaan Regresi Linear Ganda Model regresi linear ganda atas   akan ditaksir oleh
 <br><center><img src="3.png"></img></center>
<br>Dengan a0,a1,a2,...,ak  merupakan korfisien-koefisien yang harus ditentukan berdasarkan data hasil pengamatan. Analisis regresi linear berganda memerlukan pengujian secara serempak dengan menggunakan F hitung. Signifikansi ditentukan dengan membandingkan F hitung dengan F tabel atau melihat signifikansi pada output SPSS.
<br>Pengujian asumsi klasik regresi linier ganda:
<br> 1. Uji Normalitas
<br> 2. Uji Homogenitas
<br> 3. Uji Multikolinieritas
<br> 4. Uji Autokorelasi
<br> 5. Uji Heteroskedastisitas

	<div id="footer">
		
	</div>

</div>

</body>
</html>
