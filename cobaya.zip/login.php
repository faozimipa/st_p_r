<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Statistika Parametrik</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>

<body>

<div id="wrapper">

	<div id="header">
	<h1>Parametrik Online</h1>
	<h2>Memecahkan Masalah Data Statistik Anda...</h2>	
	</div>
<div id="jalan2">
<marquee>Selamat datang di Web Parametrik Online, silahkan untuk menginput, memproses dan menganalisis data Anda, Terima Kasih</marquee>
</div>
	<div id="menu">
		<ul>
			<li><a href="index.php"><span>Home</span></a></li>
			<li><a href="konsep.php"><span>Konsep Dasar</span></a></li>
			<li><a href="data.php"><span>Data</span></a></li>
			<li><a href="hubungan.php"><span>Uji Hubungan</span></a></li>
			<li><a href="banding.php"><span>Uji Banding</span></a></li>
			<li><a href="taufiq.php">My Profil</a></li>
			<li><a href="bantuan.php">Bantuan</a></li>
		</ul>
		</ul>
	</div>

	
	
				<div class="entry">
				<br>
			<center><div class="entry-title">Login Admin</div><br>
			<form action="insert_login.php" method="post" name="form" onsubmit="return cekform()">
		  <table width="301">
  <tr align="left" valign="middle">
    <td><strong>Username</strong></td>
    <td>:</td>
    <td><label for="username"></label>
    <input type="text" name="username" id="username" class="login-inp" /></td>
  </tr>
  <tr align="left" valign="middle">
    <td><strong>Password</strong></td>
    <td>:</td>
    <td><label for="password"></label>
    <input type="password" name="password" id="password" class="login-inp"/></td>
  </tr>
</table>

<br>
<input type="submit" value="LOGIN" name="login" onClick="close_window();return false;" />
        </form></center>
	<div id="footer">
		
	</div>

</div>

</body>
</html>
