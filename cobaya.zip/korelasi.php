<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Statistika Parametrik</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
</head>

<body>

<div id="wrapper">

	<div id="header">
		<h1>Parametrik Online</h1>
		<h2>Memecahkan Masalah Data Statistik Anda...</h2>
	</div>
<div id="jalan2">
<marquee>Selamat datang di Web Parametrik Online, silahkan untuk menginput, memproses dan menganalisis data Anda, Terima Kasih</marquee>
</div>
	<div id="menu">
		<ul>
			<li><a href="index.php"><span>Home</span></a></li>
			<li><a href="konsep.php"><span>Konsep Dasar</span></a></li>
			<li><a href="data.php"><span>Data</span></a></li>
			<li><a href="hubungan.php"><span>Uji Hubungan</span></a></li>
			<li><a href="banding.php"><span>Uji Banding</span></a></li>
			<li><a href="anggota.php">My Profil</a></li>
			<li><a href="bantuan.php">Bantuan</a></li>
		</ul>
		</ul>
	</div>
	
	
	
				
				<div class="entry">
				<br>
				<div class="entry-title">Uji Korelasi</div><br>
				<form method="post" action="proses3.php">
				<table>
			<tr><td>Masukkan Nama Tabel</td>
			<td><input type="text" name="nama" /></td></tr>  
			<tr><td colspan="2">*Jika tabel tidak ada, Masukkan data pada menu Data</td></tr>
			<tr><td>Masukkan Nama Variabel X</td> 
			<td><textarea name="x" id="x" cols="22" rows="1"></textarea></td></tr>
			<tr><td>Masukkan Nama Variabel Y</td> 
			<td><textarea name="y" id="y" cols="22" rows="1"></textarea></td></tr>
			</table>
		<input type="submit" name="submit" value="Submit" />
		</form>
			<br>
			<br>
		</div>


	<div id="footer">
		
	</div>

</div>

</body>
</html>